package com.vincent.testcompute

import android.net.SSLCertificateSocketFactory
import android.os.AsyncTask
import android.os.Environment

import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.FileInputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.Timer
import java.util.TimerTask

import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSession

public interface ConnectServerTaskDoneResponse {
    fun onFinalResult(responseData: String)
}


class ConnectServer : AsyncTask<Boolean, Void, String> {
    private var nTimeoutOfConnectMilliSeconds = 15000
    private var nTimeoutOfReadDataMilliSeconds = 10000
    private var mServerUrl = ""
    private var onTaskDoneResponse: ConnectServerTaskDoneResponse? = null
    private var mParameters = ""
    private var mResponse: StringBuilder? = null
    //private var mPhoneWebService: PhoneWebService? = null
    private val mDownloadFileName = ""
    private var mUploadFileName = ""
    private var mRequstMethod = ""
    private var mPostData = ""


    @JvmOverloads constructor(strServerUrl: String, strParams: String, strResponse: StringBuilder,
                              onTaskDoneResponse: ConnectServerTaskDoneResponse, timeoutConnectMilliSeconds: Int = 15000, timeoutReadMilliSeconds: Int = 10000, DownloadFileName: String = "") {
        //@JvmOverloads constructor(strServerUrl: String, strParams: String, strResponse: StringBuilder,
        //        phoneWebService: PhoneWebService, onTaskDoneResponse: ConnectServerTaskDoneResponse, timeoutConnectMilliSeconds: Int = 15000, timeoutReadMilliSeconds: Int = 10000, DownloadFileName: String = "") {
        this.mServerUrl = strServerUrl
        this.mResponse = strResponse
        this.mParameters = strParams
        //this.mContext = context;
        this.onTaskDoneResponse = onTaskDoneResponse
        this.nTimeoutOfConnectMilliSeconds = timeoutConnectMilliSeconds
        this.nTimeoutOfReadDataMilliSeconds = timeoutReadMilliSeconds

        //this.mPhoneWebService = phoneWebService

    }

    //constructor(strServerUrl: String, strParams: String, phoneWebService: PhoneWebService) {
    constructor(strServerUrl: String, strParams: String) {
        this.mServerUrl = strServerUrl
        this.mParameters = strParams
        this.mResponse = StringBuilder()

        //this.mPhoneWebService = phoneWebService
        this.onTaskDoneResponse = null
    }

    fun setTimeout(timeoutConnectSeconds: Int, timeoutReadSeconds: Int) {
        this.nTimeoutOfConnectMilliSeconds = timeoutConnectSeconds * 1000
        this.nTimeoutOfReadDataMilliSeconds = timeoutReadSeconds * 1000
    }

    fun setRequestMethod(method: String) {
        this.mRequstMethod = method
    }

    fun setPostData(postData: String) {
        this.mPostData = postData
    }

    fun setUploadFileName(UploadFileName: String) {
        this.mUploadFileName = UploadFileName
    }

    override fun doInBackground(vararg bDirectlyRun: Boolean?): String {
        if (connectToWeb(this, mServerUrl, mParameters, nTimeoutOfConnectMilliSeconds, nTimeoutOfReadDataMilliSeconds, mResponse, mDownloadFileName, mRequstMethod, mPostData, mUploadFileName)) {
            return mResponse!!.toString()
        }
        return ""
    }

    override fun onPostExecute(strResult: String) {
        super.onPostExecute(strResult)

        onTaskDoneResponse!!.onFinalResult(strResult)
    }

    override fun onCancelled() {
        onPostExecute("")
    }

    fun connectToWebDirectly(): String {
        if (connectToWeb(this, mServerUrl, mParameters, nTimeoutOfConnectMilliSeconds, nTimeoutOfReadDataMilliSeconds, mResponse, "", "", "", "")) {
            return mResponse!!.toString()
        }
        return ""
    }

    fun uploadFileToServer(url: String, parameters: String, TimeoutOfConnect: Int, TimeoutOfReadData: Int, strResponse: StringBuilder, uploadFileName: String): Boolean {
        return connectToWeb(this, url, parameters, TimeoutOfConnect, TimeoutOfReadData, strResponse, "", "POST", "", uploadFileName)
    }

    companion object {

        private val mbSSL = true
        private val hostnameVerifier = initHostnameVerifier()

        fun connectToWeb(task: ConnectServer, url: String, parameters: String, TimeoutOfConnect: Int, TimeoutOfReadData: Int, strResponse: StringBuilder?, DownloadFileName: String, newRquestMethod: String, postData: String, UploadFileName: String): Boolean {

            var httpsConnection: HttpsURLConnection? = null
            var httpConnection: HttpURLConnection? = null
            val requestMethod = if (newRquestMethod.length > 0) newRquestMethod else "GET"
            val bSSL = mbSSL
            val strRet = ""

            var bSuccess = false
            val timeoutTimer = Timer()
            try {
                timeoutTimer.schedule(TaskTimeout(task, parameters), (TimeoutOfConnect + TimeoutOfReadData + 30000).toLong())

                try {

                    if (bSSL) {
                        val mUrls = URL(url + "?")
                        httpsConnection = mUrls.openConnection() as HttpsURLConnection
                        httpsConnection.sslSocketFactory = SSLCertificateSocketFactory.getInsecure(0, null)
                        httpsConnection.hostnameVerifier = hostnameVerifier
                        httpsConnection.requestMethod = requestMethod // default: "GET"
                        if (requestMethod == "POST") {
                            httpsConnection.doOutput = true
                        }
                        httpsConnection.connectTimeout = TimeoutOfConnect
                        httpsConnection.readTimeout = TimeoutOfReadData


                        httpsConnection.connect()

                        if (requestMethod == "POST") {
                            val wr = OutputStreamWriter(httpsConnection.outputStream)
                            wr.write(postData)
                            wr.flush()
                        }

                        val responseCode = httpsConnection.responseCode

                        if (responseCode == HttpURLConnection.HTTP_OK) {
                            if (DownloadFileName.length > 0) {
                                var apkFileName = ""
                                //String fileDir = "Android/data/com.sxprotection.infield/temp";
                                val fileDir = "SXPInField"
                                val outputStream: FileOutputStream
                                //int fileLength = httpsConnection.getContentLength();
                                try {
                                    //InputStream input = new BufferedInputStream(mUrls.openStream());
                                    //BufferedReader input = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
                                    //InputStream input = new BufferedInputStream(httpsConnection.getInputStream());
                                    val input = httpsConnection.inputStream

                                    val downloadDir = Environment.getExternalStorageDirectory()
                                    //File downloadDir = Environment.getDownloadCacheDirectory();
                                    val myDir = File(downloadDir, fileDir)
                                    if (!myDir.exists())
                                        myDir.mkdirs()
                                    //File outputFile = new File(myDir, DownloadFileName);
                                    val outputFile = File(myDir, "SXPInField.apk")
                                    if (outputFile.exists()) {
                                        outputFile.delete()
                                    }
                                    outputStream = FileOutputStream(outputFile)

                                    val data = ByteArray(1024)
                                    var total: Long = 0
                                    var count: Int
                                    while (true) {
                                        count = input.read(data);
                                        if (count == -1)
                                            break;
                                        total += count.toLong()
                                        outputStream.write(data, 0, count)
                                    }

                                    outputStream.close()
                                    input.close()
                                    apkFileName = outputFile.absolutePath
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                    strResponse!!.append("ERROR: File=" + apkFileName + " [Exception]:" + e.message)
                                }

                                strResponse!!.append(apkFileName)

                                timeoutTimer.cancel()
                                return true
                            }

                            // normal web action
                            val br = BufferedReader(InputStreamReader(httpsConnection.inputStream))
                            var line: String?
                            //StringBuilder ss = new StringBuilder();
                            val ss = StringBuilder()
                            while (!task.isCancelled) {
                                line = br.readLine();
                                if (line == null)
                                    break;
                                ss.append(line + "\n")
                            }
                            br.close()
                            timeoutTimer.cancel()
                            if (!task.isCancelled) {
                                bSuccess = true
                                strResponse!!.append(ss)
                            }
                        }

                    } else {
                        //URL mUrl = new URL(url + parameters);
                        val mUrl = URL(url)
                        httpConnection = mUrl.openConnection() as HttpURLConnection
                        httpConnection.requestMethod = "GET"
                        httpConnection.connectTimeout = TimeoutOfConnect
                        httpConnection.readTimeout = TimeoutOfReadData

                        httpConnection.connect()

                        val responseCode = httpConnection.responseCode

                        if (responseCode == HttpURLConnection.HTTP_OK) {
                            val br = BufferedReader(InputStreamReader(httpConnection.inputStream))
                            var line: String?
                            val ss = StringBuilder()
                            while (!task.isCancelled) {
                                line = br.readLine();
                                if (line == null)
                                    break;
                                ss.append(line + "\n")
                            }
                            br.close()
                            timeoutTimer.cancel()

                            if (!task.isCancelled) {
                                bSuccess = true
                                strResponse!!.append(ss)
                            }
                        }
                    }
                } catch (exTimeout: SocketTimeoutException) {
                    //strResponse.append("sxptimeout");
                    strResponse!!.append("")
                    exTimeout.printStackTrace()
                } catch (e: IOException) {
                    //strResponse.append("sxptimeout");
                    strResponse!!.append("")
                    e.printStackTrace()
                } catch (ex: Exception) {
                    strResponse!!.append("")
                    ex.printStackTrace()
                } finally {
                    if (bSSL) {
                        if (httpsConnection != null)
                            httpsConnection.disconnect()
                    } else {
                        if (httpConnection != null)
                            httpConnection.disconnect()
                    }
                }
            } catch (exTimer: Exception) {
                strResponse!!.append("")
            } finally {
                timeoutTimer.cancel()
            }

            return bSuccess

        }

        private fun initHostnameVerifier(): HostnameVerifier {
            return HostnameVerifier { hostname, session ->
                //////////////////////////////////////////////////////
                // currently just trust all host. It needs to modify for security
                true
            }
        }
    }

}

internal class TaskTimeout(private val _task: ConnectServer, private val _command: String) : TimerTask() {

    override fun run() {
        _task.cancel(false)
        //if (_command.contains("&action=OK")) {
        //    Global.mainActivity.NotifyNocViaSMS(_command, "Welfare" );
        //}
    }

}