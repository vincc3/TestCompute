package com.vincent.testcompute


import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var compute = ComputeSDK();

        val editTextNumber = findViewById(R.id.editTextNumber) as EditText
        val textViewResult = findViewById(R.id.textResult) as TextView;

        val buttonGetAverage = findViewById(R.id.buttonGetAverage) as Button
        buttonGetAverage.setOnClickListener( {
            val result = compute.GetAverage();
            textViewResult.text = result.toString();
        }
        )

        val buttonAddNumber = findViewById(R.id.buttonAddNumber) as Button
        buttonAddNumber.setOnClickListener( {
            var s : String = editTextNumber.text.toString();
            compute.AddNumber(s.toDouble())
        }
        )

    }
}
