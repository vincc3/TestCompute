package com.vincent.testcompute

import org.json.JSONObject
import android.os.AsyncTask
import org.json.JSONArray



class ComputeSDK () {

    var totalNumber : Double = 0.0;
    var numberCount : Double = 1.0;

    init {
        val responseFunc = object : ConnectServerTaskDoneResponse {
            override fun onFinalResult(responseData: String) {
                val jsonArray = JSONArray(responseData)
                totalNumber = 0.0
                numberCount = jsonArray.length().toDouble();
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getString(i)
                    totalNumber += obj.toDouble()
                }
            }
        }

        var urlStr = "https://roktcdn1.akamaized.net/store/test/android/prestored_scores.json"
        var strParam = ""
        val result = StringBuilder()
        val task = ConnectServer(urlStr, strParam, result, responseFunc, 60000, 60000, "")
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, false)

    }

    fun AddNumber(number: Double) {
        totalNumber += number;
        numberCount += 1;

    }

    fun GetAverage() : Double {
        val d : Double = totalNumber/numberCount;
        return d;
    }

}

class CityWeatherData {
    var Id : Int = 0
    var cityName : String = ""
    var lat : Double = 0.00
    var lon : Double = 0.00
    var temperature : Double = 0.00
    var temp_min : Int = 0
    var temp_max : Int = 0
    var humidity : Int = 0
    var weather_main = ""
    var description = ""

    constructor(jsonString: String) {
        var obj = JSONObject(jsonString);
        var gpsLocation = obj.getJSONObject("coord");
        var weather = obj.getJSONArray("weather").getJSONObject(0);
        var temp = obj.getJSONObject("main");

        Id = obj.getInt("id")
        cityName = obj.getString("name")
        lat = gpsLocation.getDouble("lat")
        lon = gpsLocation.getDouble("lon")
        weather_main = weather.getString("main")
        description = weather.getString("description")

        temperature = temp.getDouble("temp")
        temp_min = temp.getInt("temp_min")
        temp_max = temp.getInt("temp_max")
        humidity = temp.getInt("humidity")

    }
}


